// /api/cnpj.js — Vercel serverless
export default async function handler(req, res) {
  try {
    const { tipo = "basica", cnpj } = req.query;
    if (!cnpj) return res.status(400).json({ error: "Informe ?cnpj=14_digitos" });

    const tokenUrl = `${process.env.CONECTA_BASE}/oauth2/jwt-token`;
    const scope = process.env.CONECTA_SCOPE || "api-cnpj-v1";

    const basic = Buffer.from(`${process.env.CONECTA_CLIENT_ID}:${process.env.CONECTA_CLIENT_SECRET}`).toString("base64");

    const form = new URLSearchParams();
    form.set("grant_type", "client_credentials");
    form.set("scope", scope);

    const tok = await fetch(tokenUrl, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${basic}`,
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: form
    });

    if (!tok.ok) {
      const t = await tok.text();
      return res.status(tok.status).json({ error: "Falha ao obter token", details: t });
    }
    const { access_token } = await tok.json();

    const map = {
      basica:  "/api-cnpj-basica/v2/basica",
      qsa:     "/api-cnpj-qsa/v2/qsa",
      empresa: "/api-cnpj-empresa/v2/empresa"
    };
    const path = map[tipo];
    if (!path) return res.status(400).json({ error: "tipo inválido (basica|qsa|empresa)" });

    const url = `${process.env.CONECTA_BASE}${path}/${cnpj}`;

    const r = await fetch(url, {
      headers: {
        "Authorization": `Bearer ${access_token}`,
        "x-cpf-usuario": process.env.CONECTA_CPF_USUARIO
      }
    });

    const txt = await r.text();
    res.status(r.status).setHeader("Content-Type", r.headers.get("content-type") || "application/json");
    return res.send(txt);
  } catch (e) {
    return res.status(500).json({ error: "erro inesperado", details: String(e) });
  }
}
