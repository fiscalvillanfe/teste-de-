// /api/motivo-bio.js — Vercel serverless (Edge runtime opcional)
export const config = { runtime: "edge" };

export default async function handler(req) {
  try {
    const body = req.method === "POST" ? await req.json() : {};
    const { contexto = "Impossibilidade temporária na coleta", tom = "curto" } = body;

    const prompt = `Você é um gerador de justificativas para AGR.
Contexto: ${contexto}
Tom: ${tom}
Regras:
- Gere 5 motivos, cada um em UMA linha, sem numeração.
- 3 curtos (<= 120 caracteres) e 2 formais (120-200 caracteres).
- Use termos: biometria, impossibilidade temporária, agendamento, reagendamento, impedimento físico.
- Não invente dados, nada de PII.`;

    const endpoint = "https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent";
    const resp = await fetch(`${endpoint}?key=${process.env.GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
    });

    if (!resp.ok) {
      const t = await resp.text();
      return new Response(JSON.stringify({ error: "falha Gemini", details: t }), { status: 500 });
    }

    const data = await resp.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    const motivos = text.split(/\r?\n/).filter(Boolean).slice(0, 5);
    return new Response(JSON.stringify({ motivos }), { status: 200 },);
  } catch (e) {
    return new Response(JSON.stringify({ error: "erro inesperado", details: String(e) }), { status: 500 });
  }
}
