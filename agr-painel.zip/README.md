# Painel AGR — Dossiês & Consultas (GitHub Pages + Vercel)

Painel para **Agente de Registro**: ficha do cliente, dossiê (PDF/ZIP), **consulta CNPJ** via Conecta/SERPRO (sandbox) e **gerador de motivos de biometria** via Gemini.

## Estrutura
```
/
├─ index.html
├─ assets/styles.css
├─ js/
│  ├─ config.js          # edite API_BASE com a URL do Vercel
│  └─ app.js
└─ api/
   ├─ cnpj.js            # OAuth2 + chamadas CNPJ (basica/qsa/empresa)
   └─ motivo-bio.js      # Gemini (gera motivos de biometria)
```

## Deploy

### GitHub Pages (frontend)
1. Repositório público `agr-painel`.
2. Upload de todos os arquivos e pastas.
3. Settings → Pages → Branch `main` / Folder `/root`.

### Vercel (backend)
Env vars necessárias (Project Settings → Environment Variables):
- `CONECTA_CLIENT_ID`
- `CONECTA_CLIENT_SECRET`
- `CONECTA_SCOPE` = `api-cnpj-v1`
- `CONECTA_BASE` = `https://h-apigateway.conectagov.np.estaleiro.serpro.gov.br`
- `CONECTA_CPF_USUARIO` = **seu CPF**
- `GEMINI_API_KEY` = **sua chave do Google AI Studio**

Faça o deploy e copie a URL (ex.: `https://seuapp.vercel.app`).

### Conectar
Edite `js/config.js`:
```js
window.APP_CONFIG = { API_BASE: "https://seuapp.vercel.app" };
```

## Uso
- **Consulta CNPJ**: informe 14 dígitos, escolha tipo e consulte.
- **Biometria**: gere 5 motivos (3 curtos, 2 formais) prontos para copiar.
- **Dossiê**: gere PDF/ZIP, exporte Excel.
- **Sessão**: dados salvos localmente (arquivos não).

## Segurança
- Não comitar chaves. Só em variáveis de ambiente da Vercel.
- Se expôs chaves, **revogue e gere novas**.
