// Lógica do Painel AGR — cliente
const $ = (s)=>document.querySelector(s);

const state = {
  cliente: { nome:"", cnpj:"", cpf:"", email:"", telefone:"", endereco:"", obs:"" },
  arquivos: []
};

function toast(msg){
  const n = document.createElement("div");
  n.className = "chip"; n.style.position="fixed"; n.style.bottom="16px"; n.style.right="16px"; n.style.zIndex="999";
  n.textContent = msg; document.body.appendChild(n); setTimeout(()=>n.remove(), 2200);
}
function humanFileSize(bytes){
  const u=['B','KB','MB','GB']; let i=0; while(bytes>=1024 && i<u.length-1){bytes/=1024;i++;}
  return bytes.toFixed(1)+" "+u[i];
}
function saveLocal(){ localStorage.setItem("agr-painel", JSON.stringify(state)); }
function loadLocal(){
  try{ const raw = localStorage.getItem("agr-painel"); if(!raw) return;
    const data = JSON.parse(raw); state.cliente = {...state.cliente, ...(data.cliente||{})};
    const f = $("#clienteForm");
    Object.entries(state.cliente).forEach(([k,v])=>{ if(f.elements[k]) f.elements[k].value = v || ""; });
    toast("Sessão carregada."); }catch{}
}
function renderFiles(){
  const ul = $("#fileList"); ul.innerHTML="";
  state.arquivos.forEach((f,idx)=>{
    const li = document.createElement("li");
    li.innerHTML = `<div><strong>${f.name}</strong><div class="muted">${humanFileSize(f.size)}</div></div>`;
    const b = document.createElement("button"); b.className="btn ghost"; b.textContent="remover";
    b.onclick=()=>{ state.arquivos.splice(idx,1); renderFiles(); };
    li.appendChild(b); ul.appendChild(li);
  });
}

// --- Cliente form
$("#btnSalvarCliente").onclick = ()=>{
  const form = $("#clienteForm");
  ["nome","cnpj","cpf","email","telefone","endereco","obs"].forEach(k=> state.cliente[k] = form.elements[k].value.trim());
  saveLocal(); toast("Dados salvos.");
};
$("#btnLimparCliente").onclick = ()=>{ $("#clienteForm").reset(); Object.keys(state.cliente).forEach(k=>state.cliente[k]=""); toast("Limpo."); };

// --- Dropzone
const dz = $("#dropzone"); const fi = $("#fileInput");
dz.addEventListener("dragover",(e)=>{e.preventDefault(); dz.classList.add("drag");});
dz.addEventListener("dragleave",()=>dz.classList.remove("drag"));
dz.addEventListener("drop",(e)=>{e.preventDefault(); dz.classList.remove("drag"); state.arquivos.push(...e.dataTransfer.files); renderFiles();});
dz.addEventListener("click",()=>fi.click());
fi.addEventListener("change",()=>{ state.arquivos.push(...fi.files); fi.value=""; renderFiles();});

// --- PDF capa+resumo
$("#btnGerarPDF").onclick = async()=>{
  if(!window.jspdf){ alert("jsPDF não carregou."); return; }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({unit:"pt",format:"a4"});
  const m=48; let y=m;
  doc.setFont("helvetica","bold"); doc.setFontSize(18); doc.text("Dossiê — Resumo", m,y); y+=22;
  doc.setFont("helvetica","normal"); doc.setFontSize(11);
  const L = [
    `Cliente: ${state.cliente.nome||"-"}`,
    `CNPJ: ${state.cliente.cnpj||"-"} • CPF: ${state.cliente.cpf||"-"}`,
    `E-mail: ${state.cliente.email||"-"} • Tel: ${state.cliente.telefone||"-"}`,
    `Endereço: ${state.cliente.endereco||"-"}`,
    `Obs: ${state.cliente.obs||"-"}`,
  ];
  L.forEach(t=>{ doc.text(t,m,y); y+=16; });
  y+=8; doc.setFont("helvetica","bold"); doc.text("Anexos:", m,y); y+=16; doc.setFont("helvetica","normal");
  if(state.arquivos.length===0){ doc.text("— Nenhum anexo.", m,y); }
  else state.arquivos.forEach((f,i)=>{ if(y>780){doc.addPage(); y=m;} doc.text(`${i+1}. ${f.name} (${humanFileSize(f.size)})`, m,y); y+=16; });
  const blob = doc.output("blob");
  saveAs(blob, `DOSSIE_${(state.cliente.nome||"CLIENTE").replace(/\s+/g,"_")}.pdf`);
};

// --- ZIP com PDF + originais
$("#btnGerarZIP").onclick = async()=>{
  if(state.arquivos.length===0){ alert("Adicione anexos ao dossiê."); return; }
  const { jsPDF } = window.jspdf;
  let pdfBlob;
  if(jsPDF){
    const doc = new jsPDF({unit:"pt",format:"a4"});
    const m=48; let y=m; doc.setFont("helvetica","bold"); doc.setFontSize(18); doc.text("Dossiê — Capa & Resumo", m,y); y+=22;
    doc.setFont("helvetica","normal"); doc.setFontSize(11);
    [`Cliente: ${state.cliente.nome||"-"}`, `CNPJ: ${state.cliente.cnpj||"-"} • CPF: ${state.cliente.cpf||"-"}`].forEach(t=>{doc.text(t,m,y); y+=16;});
    pdfBlob = doc.output("blob");
  }
  const zip = new JSZip(); if(pdfBlob) zip.file("DOSSIE_RESUMO.pdf", pdfBlob);
  const orig = zip.folder("originais"); for(const f of state.arquivos){ orig.file(f.name, await f.arrayBuffer()); }
  const out = await zip.generateAsync({type:"blob"});
  saveAs(out, `DOSSIE_${(state.cliente.nome||"CLIENTE").replace(/\s+/g,"_")}.zip`);
};

// --- Renomear ZIP
$("#btnRenomearZip").onclick = async()=>{
  if(state.arquivos.length===0){ alert("Adicione arquivos."); return; }
  const p = ($("#rnPrefixo").value || (state.cliente.nome||"CLIENTE").replace(/\s+/g,"_")).toUpperCase();
  const c = ($("#rnCnpj").value || "").replace(/\D+/g,"") || (state.cliente.cnpj||"").replace(/\D+/g,"") || "CNPJ";
  const ymd = new Date().toISOString().slice(0,10).replace(/-/g,"");
  const zip = new JSZip(); let n=1;
  for(const f of state.arquivos){
    const ext = f.name.includes(".")? f.name.split(".").pop() : "dat";
    const novo = `${p}_${c}_${ymd}_${String(n++).padStart(2,"0")}.${ext}`;
    zip.file(novo, await f.arrayBuffer());
  }
  const out = await zip.generateAsync({type:"blob"});
  saveAs(out, `RENOMEADOS_${p}_${ymd}.zip`);
};

// --- Excel
$("#btnExcel").onclick = ()=>{
  const wb = XLSX.utils.book_new();
  const meta = [
    ["Cliente", state.cliente.nome||""],
    ["CNPJ", state.cliente.cnpj||""],
    ["CPF", state.cliente.cpf||""],
    ["E-mail", state.cliente.email||""],
    ["Telefone", state.cliente.telefone||""],
    ["Endereço", state.cliente.endereco||""],
    ["Observações", state.cliente.obs||""],
    ["Gerado em", new Date().toLocaleString("pt-BR")]
  ];
  const ws1 = XLSX.utils.aoa_to_sheet(meta);
  XLSX.utils.book_append_sheet(wb, ws1, "Resumo");

  const rows = [["Arquivo","Tamanho"]];
  state.arquivos.forEach(f=> rows.push([f.name, humanFileSize(f.size)]));
  const ws2 = XLSX.utils.aoa_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws2, "Anexos");

  XLSX.writeFile(wb, `RELATORIO_${(state.cliente.nome||"CLIENTE").replace(/\s+/g,"_")}.xlsx`);
};

// --- Sessão
$("#btnSalvarSessao").onclick = saveLocal;
$("#btnCarregarSessao").onclick = loadLocal;

// --- Consultar CNPJ (via Vercel)
$("#btnConsultarCnpj").onclick = async()=>{
  const API = (window.APP_CONFIG && window.APP_CONFIG.API_BASE) || "";
  if(!API){ alert("Configure js/config.js com API_BASE (domínio Vercel)."); return; }
  const cnpj = ($("#cnpjInput").value||"").replace(/\D+/g,"");
  const tipo = $("#tipoConsulta").value;
  if(cnpj.length!==14){ alert("CNPJ deve ter 14 dígitos."); return; }
  $("#saidaCnpj").textContent = "Consultando...";
  const r = await fetch(`${API}/api/cnpj?tipo=${encodeURIComponent(tipo)}&cnpj=${encodeURIComponent(cnpj)}`);
  const txt = await r.text();
  try{
    const data = JSON.parse(txt);
    $("#saidaCnpj").textContent = JSON.stringify(data, null, 2);
    if(data.nomeEmpresarial) $("#clienteForm").elements["nome"].value = data.nomeEmpresarial;
    if(data.correioEletronico) $("#clienteForm").elements["email"].value = data.correioEletronico;
  }catch{
    $("#saidaCnpj").textContent = txt;
  }
};

// --- Motivo biometria (Gemini via Vercel)
$("#btnGerarMotivo").onclick = async()=>{
  const API = (window.APP_CONFIG && window.APP_CONFIG.API_BASE) || "";
  if(!API){ alert("Configure js/config.js com API_BASE."); return; }
  const contexto = $("#ctxMotivo").value || "Impossibilidade temporária de coleta";
  const tom = $("#tomMotivo").value;
  $("#saidaMotivo").textContent = "Gerando...";
  const r = await fetch(`${API}/api/motivo-bio`, {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ contexto, tom })
  });
  const data = await r.json();
  $("#saidaMotivo").textContent = (data.motivos||[]).join("\n");
};

// init
window.addEventListener("DOMContentLoaded", ()=>{ loadLocal(); });
