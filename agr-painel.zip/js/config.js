// js/config.js — EDITE APENAS A URL DO VERCEL AQUI
window.APP_CONFIG = {
  API_BASE: "https://SEU-PROJETO.vercel.app" // <- troque para a URL do seu Vercel
};
